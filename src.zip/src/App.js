import NewNote from "./Components/NewNote";
import NoteList from "./Components/NoteList";
import React from 'react';

const App = () => {
  return (
    <div>
      <div class="heading">Notes</div>
      <div class="row">
        <NoteList />
        <NewNote />
      </div>
    </div>      
  );
};

export default App;


