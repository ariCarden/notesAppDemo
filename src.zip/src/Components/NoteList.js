import React, {Component} from 'react';
import {connect} from 'react-redux';
import Note from './Note';
import EditNote from './EditNote';


class NoteList extends Component {
    render() {
        return (
            <div className = "note-container">
                <div className="note_list_heading">All Notes</div>
                {this.props.notes.map((note) => (
                    <div key={note.id}>
                        {note.editing ? <EditNote note={note} key={note.id}/> :
                            <Note key={note.id} note={note}/>}
                    </div>
                ))}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        notes: state
    }
};


export default connect(mapStateToProps)(NoteList);

